import json,copy,hashlib
from pathlib import Path
from r19_metadata import M
P=Path(__file__).resolve().parents[1]
base=json.loads((P/'audit/r19-first-config-transcription.json').read_text())
r17=json.loads((P/'sources/R17.json').read_text())
print('R17 keys',r17.keys())
# Task metrics from the R17 verified source.
tasks=r17['tasks']
out=[]; checks=[]
for i,(t,ntr,nva,nte,vsha,tsha,ref,expected) in enumerate(M):
 for tag,drop in [('H0',.1),('H1',.3)]:
  for seed in [44,45]:
   c=copy.deepcopy(base);c['task']=t;c['inputs']['train'].update(task_selector=t,rows=ntr)
   c['inputs']['validation'].update(rows=nva,sha256=vsha);c['inputs']['test'].update(rows=nte,sha256=tsha)
   c['split']['split_id']=t+'__official-train__raw-smiles-group__s43__stop010__v1'
   c['head']['dropout']=drop;c['training']['model_seed']=seed;c['evaluation']['task_score_reference_metric']=ref
   metric=tasks[t]['metric']
   if metric in ['AUROC','AUPRC']:
    c['target'].update(kind='binary_classification',positive_label=1,transform='none',inverse_transform_at_prediction=False,prediction_scale='sigmoid(logit) continuous P(Y=1), no threshold, no target scaling')
    c['loss'].update(name='BCEWithLogitsLoss',target_scale='binary_0_1',pos_weight=1.0)
    c['early_stopping'].update(metric_input='sigmoid of finite logits cast to float64; same probabilities as export, no threshold or clipping',metric='AP' if metric=='AUPRC' else 'AUROC',definition='average precision over grouped identical scores, no trapezoidal PR interpolation' if metric=='AUPRC' else 'continuous-score ROC AUC with averaged tied ranks',direction='maximize')
   elif metric=='Spearman':
    c['early_stopping'].update(metric='Spearman',definition='Pearson correlation of average tied ranks',direction='maximize')
   sha=hashlib.sha256(json.dumps(c,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
   idx=i*4+(0 if tag=='H0' else 2)+(seed-44)
   item={'source_entry_id':'R19-prior-H-2cdcdf014e443ab866c8','source_lines':[9+192*idx,200+192*idx], 'proposal_id':f'P-{"S1" if i<10 else "S1B"}-{t}-{tag}','batch_id':'S1' if i<10 else 'S1B','task':t,'config_tag':tag,'model_seed':seed,'split_seed':43,'split_id':c['split']['split_id'],'full_config':c,'scientific_config_sha256':sha,'is_executed':False}
   out.append(item)
   if tag=='H0' and seed==44 and expected:
    checks.append({'task':t,'expected':expected,'actual':sha,'matches':sha==expected})
(P/'audit/r19-expanded-configs.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(P/'audit/r19-config-hash-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print('observed hash checks',sum(x['matches'] for x in checks),'/',len(checks));print('totals train/valid/test',*[sum(r[k] for r in M) for k in [1,2,3]])
for x in checks:
 if not x['matches']:print('MISMATCH',x)
for r in out:print(r['task'],r['config_tag'],r['model_seed'],r['scientific_config_sha256'])
