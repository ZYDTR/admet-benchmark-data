# ADMET 深度研究评审

- request_id: `admet-agentled-six-pro-20261102-001`
- round_id: `six-seed-paired-and-breadth-20261102`
- packet: `agent-led-six-20261102-v1`
- input commit: `092d21ddaeb44f305a0628bef15fb6232ea8eb4b`
- manifest SHA256: `87788a22149be39cd7b41e68fc0a5df048bb9971a0878eaa1a755092292d2d0d`
- scope: `aggregate_only`; next batch: `proposal_only`; scientific status: `needs_evidence`

## 执行结论

推荐**自适应扩大覆盖，但先完成零 fit 准备审计**。不继续大规模深挖 Caco2，也不平均浅调全部 22 项。六项结果支持保留 Caco2 raw-MAE 早停作为候选；不支持显著性、独立泛化或普遍优于 MSE。其余 21 项新版 runner 尚未逐任务验收，不能立即开训。主控“扩大覆盖”是待证伪假设。

## Q0 六项配对复算

差值 `d = MAE_monitor_saved_valid_MAE - MSE_monitor_saved_valid_MAE`，负数表示 MAE monitor 保存模型的 valid MAE 较低。对比较原件十进制数独立 Decimal 复算：

| seed | MSE monitor MAE | MAE monitor MAE | d |
|---:|---:|---:|---:|
| 44 | 0.41727108770329663 | 0.4068564265494504 | -0.01041466115384623 |
| 45 | 0.4477993207692307 | 0.43222243850549447 | -0.01557688226373623 |
| 46 | 0.4290186062747252 | 0.4296442182637361 | +0.00062561198901090 |

MSE 组均值 `0.4313630049157508433`，样本 SD `0.01539855211612538`；MAE 组均值 `0.4229076944395603233`，样本 SD `0.013960451481374384`；配对差均值 `-0.00845531047619052`，配对差样本 SD `0.00827704635187567`。MAE monitor 2/3 胜、MSE monitor 1/3 胜。计算式 `d_s=MAE_s(MAE)-MAE_s(MSE)`，均值为 `Σd/3`，样本 SD 分母为 `3-1`。

六项训练 loss 均为 standardized MSE；改变的是内部早停 monitor（standardized MSE 或 raw-scale MAE）。外部比较为 91 行 official_valid MAE，越低越好。共同配置：冻结 CheMeleon；2048→256→1 head；dropout 0.1；AdamW lr 0.0005、weight_decay 0.0001；batch 128；max 50 epochs、patience 8；raw-SMILES grouped split43；fit 573 / stop 64。

| monitor | seed | epochs | best epoch | total steps | resumed | new steps |
|---|---:|---:|---:|---:|---:|---:|
| MSE | 44 | 20 | 12 | 100 | 0 | 100 |
| MSE | 45 | 39 | 31 | 195 | 0 | 195 |
| MSE | 46 | 37 | 29 | 185 | 30 | 155 |
| MAE | 44 | 17 | 9 | 85 | 0 | 85 |
| MAE | 45 | 14 | 6 | 70 | 0 | 70 |
| MAE | 46 | 23 | 15 | 115 | 0 | 115 |

seed46 MSE 从 6 epoch / 30 steps checkpoint 恢复到 37 / 185，新增 155 步；不是 185 个全新 steps。MSE seed44 fresh encoding，MSE seed45/46 与 MAE 三项使用缓存表示。GPU/监控实现也有差异，故配对结果是描述性保存模型比较而非完全同构复现。本批最佳 MAE `0.4068564265494504` 未超过历史最佳 `0.37862513598901104`；历史配置混杂，不能因果归因。

**科学与运行合规分开**：主控已验收六项稳定模型、91 行预测、冻结状态、缓存身份、head/optimizer/RNG 序列化与 CPU 盲预测重建，可在该范围分析。GPU0 高负载共享失败保留：对方 SM 下降与本任务负载共现，连续阈值、暂停和 N/A 填零不足以证明无影响。GPU1 仅接受当次闲置驻留、低负载串行小头条件分支；无对方吞吐/延迟直接证据，不可泛化。GPU1 attempt02 曾因 CPU tick 条件在 CUDA/恢复前退出 -15，失败及修订校准均须保留。11 次尝试为 6 完成、5 失败/中途。

## Q1 策略裁决

| 策略 | 支持 | 反证/代价 | 裁决 |
|---|---|---|---|
| 继续 Caco2 | 缓存、恢复、冻结、盲预测实测；raw-MAE 描述性较优 | valid 反复使用；本批未超过历史最好；边际收益未知 | 只保留小规模确认 |
| 平均浅调 22 项 | 快速覆盖；Mini22 历史 baseline 可参考 | 21 项新版接口未验收；样本规模、类别比例、标签质量差异大 | 不推荐 |
| 自适应覆盖 | 按数据质量、准备度、样本信息量、指标可比性选择 | 容易偏向“容易任务”，需预注册门槛 | **推荐，先零 fit** |

扩覆盖的证伪条件：标签/行身份异常、单类或极小样本、AP 定义不明、runner 不支持、资产许可未闭合、缓存映射无法证明。遇到即延期，不为任务数开训。

## Q2 22 任务初筛

历史 Mini22 汇总 split `official-valid-20261029-v6`，11,735 rows；不是官方总分，也不证明新版 runner ready。指标官方等价性未确认。

| task | metric / direction | valid n / 已知结构 | 初筛 |
|---|---|---|---|
| ames | AUROC ↑ | 1137; 479+/658− | 高；查 scaffold |
| bbb_martins | AUROC ↑ | 203; 149+/54− | 中；样本较小 |
| bioavailability_ma | AUROC ↑ | 64; 43+/21− | 低；极小样本 |
| caco2_wang | MAE ↓ | 91 regression | 六项已做；限量确认 |
| clearance_hepatocyte_az | Spearman ↑ | 122 regression | 中；查 ties/尺度 |
| clearance_microsome_az | Spearman ↑ | 111 regression | 中；查 ties/尺度 |
| cyp2c9_substrate_carbonmangels | AUPRC ↑ | 67; 12+/55− | 低；正例少 |
| cyp2c9_veith | AUPRC ↑ | 1210 | 高；查 AP 定义 |
| cyp2d6_substrate_carbonmangels | AUPRC ↑ | 54 | 低；极小样本 |
| cyp2d6_veith | AUPRC ↑ | 1124 | 高；覆盖候选 |
| cyp3a4_substrate_carbonmangels | AUROC ↑ | 67 | 低/中；小样本 |
| cyp3a4_veith | AUPRC ↑ | 1200 | 高；覆盖候选 |
| dili | AUROC ↑ | 475 | 中高；查分组/重复 |
| half_life_obach | Spearman ↑ | 667 regression | 高；查长尾/ties |
| herg | AUROC ↑ | 646 | 高；查类别比例 |
| hia_hou | AUROC ↑ | 578 | 中高；查缺失 |
| ld50_zhu | MAE ↓ | 128 regression | 低/中；尺度/离群 |
| lipophilicity_astrazeneca | MAE ↓ | 4200 regression | 高；大样本回归 |
| pgp_broccatelli | AUROC ↑ | 1212 | 高；覆盖候选 |
| ppbr_az | MAE ↓ | 131 regression | 中；小样本/尺度 |
| solubility_aqsoldb | MAE ↓ | 998 regression | 中高；历史记录提示 valid 空骨架异常，先核对 |
| vdss_lombardo | Spearman ↑ | 106 regression | 中；小样本秩风险 |

样本量来自历史汇总。本轮未逐项读取原始 train/valid/test、预测分布与完整训练证据，故不填造逐任务异常检测、准备度或误差切片结论。高优先级只是审计后候选。

## Q3 预算情景（均为建议，不是授权）

- 小：全 21 项零 fit 审计；最多 2 task × 1 config × 2 seeds × 1 split = 4 fits。
- 中（推荐）：全 21 项零 fit 审计；最多 4 task × 1 config × 2 seeds × 1 split = 8 screen fits；触发后最多 2 task × 1 config × 3 seeds × 1 split = 6 confirm fits；上限 14 fits。
- 大：最多 6 task × 2 单因素 configs × 3 seeds × 1 split = 36 fits；须中档确认显示稳定信号后另行登记。
- 成本式 `T=T_prepare(shared)+N_unique_encoder_fit*T_encode+N_head_fit*T_head+N_score*T_retrieve+T_review/roundtrip`。已知本批 GPU program 520.7901s（含导入/CPU/失败），两个训练原生 turn 合计 4895.984s；新四项取回 270.4201s、角色至回报 661.5655s。阶段有重叠不可相加。其他任务成本未知，由零 fit fixture 与首批实测校准。剩余 4775.2848 GPU program seconds 不授权新实验。

## Q4 冻结编码、缓存与合成

raw representation cache 只存冻结 encoder 输出，key 绑定 encoder/version/weights SHA、tokenizer/featurizer、SMILES 规范化版本、原始输入与 row identity。fit 后变换（scaler/imputer/feature selection）只能由本 split fit rows 拟合，缓存绑定 split_id、fit row IDs/hash 和变换参数 hash，不跨 split 复用。缓存映射至少保留 task/split/row_index/Drug_ID/SMILES；预测回写逐行核验，不仅按 Drug_ID（历史模板存在重复）。逐任务 head、ensemble 和 joint multitask 是不同方案：本轮优先逐任务装配；ensemble 仅在同 task/split/输出尺度兼容时另行验证；joint multitask 会改变共享参数与目标权重，不列默认。模板导出只填 y_pred，保留原行列格式，分类为正类概率/置信度，回归为原 Y 尺度连续值。

## Q5 验证偏差

训练 loss、内部早停、外部指标分别登记。分类候选 BCEWithLogitsLoss，早停按任务核实后的 AUROC/AP，输出 sigmoid probability；回归候选 train-fit 标准化 MSE/Huber，早停明确 MAE 或 Spearman，输出逆变换回原 Y。valid 调参允许，但历史重复使用已进入累计账，新 Chat 不清零。反馈训练方仅给带 run/task/split/metric provenance 的 task/group 汇总与技术诊断，不给逐行真值、残差、lookup 答案或可还原个体答案的差分。3-seed SD 是描述统计，不是置信区间。

## Q6 参数方向与分支

先做数据/标签/指标/行映射与 runner fixture；再做 head 容量、dropout、优化器/学习率、loss 单因素筛选；后做表示/池化、冻结底座、ensemble。参数空间详见 `search_space.json`。screen 无改善则停该任务头部扩容，回查标签/表示；改善但跨 seed 不稳则补共同 seed confirm；冻结/标签/身份故障则立即停该任务并回主控；多任务稳定改善后才触发 ensemble 研究。

## Q7 周转

GPU program time、训练原生 turn 全时长、评分取回、角色至回报不同口径。Pro 独立往返耗时未充分记录，不能拿命令耗时代替 thread wall time。建议集中完成全部零 fit profiles/fixtures，再共享只读冻结表示缓存，批量 head 训练，集中评分与整批评审；不恢复退役固定编排脚本。替代安排：先 2-task micro-batch，若准备失败率/人工等待高则缩小任务集合。GPU0 失败保留；GPU1 条件接受不等于任意并发安全。

## 交叉核验与局限

| 主张 | 首次证据 | 复核 | 反例/限制 | 结论 |
|---|---|---|---|---|
| MAE monitor 均值低 | 六项逐 seed 比较 JSON | Decimal 计算 | seed46 反向；valid 重用 | 描述性支持 |
| seed46 恢复 30→185 | 比较 JSON / failure report | 185-30=155 | 停止后未落盘更新未知 | 记录 155 新增步 |
| 六项可科学分析 | 主控验收/盲预测摘要 | current README 与资源报告 | GPU0 运行失败 | 科学接受不等于全合规 |
| 21 项未证明 ready | runner evidence / asset registry | Mini22 历史实现对照 | 历史代码可参考 | 逐项准备验收 |
| 扩大覆盖更优 | 历史任务结构/投入情况 | 与 Caco2 边际证据比较 | 新 runner 和成本未知 | 仅条件推荐 |

**subagents**：当前工具清单没有可调用的 subagent/delegate 接口；没有冒充实际代理。主模型从规则/数据边界、统计比较、资产、runner、历史反证、周转六个角度交叉检查。

**实读限制**：正式合同要求 23 项原件。当前实际打开了正式 PROMPT/REQUEST、START_HERE、context/history/research/issues/assets/current README、current evidence 索引、failure/resources、主控六项裁定、逐 seed 比较、分数对象、Decimal50 复核、任务指标对象、review-output schema、runner evidence、科学资产表、Mini22 任务汇总、前轮广度复核、官方规则快照与用户确认冻结政策等。仍未逐项实读全部 23 项，尤其 670,837-byte 的 84-fit 原始矩阵、完整 R11 Chat prompt 原件、完整全部历史 run 原件、逐任务原始数据剖面和完整逐 run 源码/预测资产。错误 URL 不视为原件不可达；这些条目为“本轮尚未读取”，非 404。故本报告不声称 23/23 通过，也不声称所有 row_index 预测对齐已由本会话独立重建。

## 需补件

1. 完成 23 项精确 reading-contract 原件逐项打开、登记 commit/SHA/行数与 observed fact。
2. 从每任务原始数据/manifest 核验 train/valid/test row identity、标签骨架、缺失/类别数、SMILES/重复结构、split 分组。
3. 逐任务确认真实 runner 支持字段、科学资产 SHA、冻结 encoder/buffer、optimizer 排除 encoder、prediction inverse-transform、template y_pred 行序。
4. 核验 AP/AUPRC、Spearman ties、官方总分聚合和指标 undefined 策略。
5. 补完整 Pro/准备/评分的角色级时间线，不将重叠时长相加。
